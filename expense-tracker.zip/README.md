# Automated Expense Tracker

This is a personal project to automate the extraction, storage, and visualization of financial data from Gmail emails and password-protected PDF statements. The solution leverages Python for backend automation, PostgreSQL for data storage, and Streamlit for dashboarding.

## 🔧 Tech Stack
- Python (`imaplib`, `email`, `PyPDF2`, `pdfplumber`, `re`, `beautifulsoup4`, `pandas`, `sqlalchemy`, `psycopg2`, `datetime`)
- PostgreSQL
- Streamlit
- AWS EC2 (for deployment)

## 📂 Features
- Parses Gmail inbox for statement emails and extracts financial data from email bodies and PDF attachments
- Decrypts password-protected PDFs using PyPDF2 and extracts tables with pdfplumber
- Stores parsed data in PostgreSQL with deduplication and incremental inserts
- Interactive dashboard for filtering and exploring expense data by category, month, and card type
- Lightweight UI built with Streamlit, hosted on AWS EC2

## 🚀 Setup Instructions
1. Clone the repository
2. Create a `.env` file for email credentials and database config
3. Install dependencies: `pip install -r requirements.txt`
4. Run the dashboard: `streamlit run app.py`

## 📸 Screenshots
*(Add screenshots of dashboard here)*

---

> Developed as a personal project to demonstrate end-to-end BI automation and dashboarding.
