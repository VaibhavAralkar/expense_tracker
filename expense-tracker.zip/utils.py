# Helper functions placeholder
